package com.example.taxifinder.model

data class TaxiCompany (
    val id: String = "0",
    val name: String = "Default TaxiCompany name",
    val address: String = "Default TaxiCompany address",
    val phoneNumber: String = "Default TaxiCompany phone number"
)